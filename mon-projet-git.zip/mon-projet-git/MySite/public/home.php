<div class="container container-home m-0 p-0">
	<h3 class="m-2">Actualites</h3>
	<div class="d-flex home-box mb-2">
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">
					un enfant se cache le visage
				</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/hideface.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">un enfant se cache le visage</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/dansleau.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">un enfant se cache le visage</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/galaxy.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">un enfant se cache le visage</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/lever.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
	</div>
	<div class="d-flex home-box mb-2">
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">
					un enfant se cache le visage
				</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/plage.jpg" width="96%" alt="">
				</div>
			</a>
		</div>
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">un enfant se cache le visage</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/light.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">
				<h5 class="home-title px-0">un enfant se cache le visage</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/football.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
		<div class="w-25 m-0 p-0">
			<a href="#" class="m-0 p-0">	
				<h5 class="home-title px-0">un enfant se cache le visage</h5>
				<div class="w-100 m-0 p-0">
					<img src="/media/babyboy.jpg" width="96%" alt="">
				</div>
			</a>	
		</div>
	</div>
</div>