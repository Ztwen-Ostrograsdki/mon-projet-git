<?php 

function e($string){
	return htmlspecialchars($string);
}


