<?php

namespace Vincent\Admin;



class Config{









	
}